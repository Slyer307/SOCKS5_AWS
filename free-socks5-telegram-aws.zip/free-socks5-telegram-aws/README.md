# 🛰️ Proxy SOCKS5 miễn phí trên AWS cho Telegram (Port 443, không xác thực)

> Dự án giúp bạn triển khai **SOCKS5 proxy** trên **AWS EC2 miễn phí**, tối ưu kết nối từ **Việt Nam**, đặc biệt dùng cho **Telegram**.

## ✅ Tính năng

- Cài đặt máy ảo miễn phí AWS (f1-micro hoặc t4g.micro)
- Tự động cài proxy SOCKS5 bằng Dante (cổng 443)
- Không yêu cầu username/password
- Tự động khởi động khi reboot VPS
- Tối ưu mạng cho kết nối ổn định và ping thấp từ Việt Nam

## 🚀 Hướng dẫn nhanh

```bash
curl -O https://raw.githubusercontent.com/Slyer307/free-socks5-telegram-aws/main/setup-dante-443.sh
chmod +x setup-dante-443.sh
./setup-dante-443.sh
```

## 📜 Giấy phép

MIT License
